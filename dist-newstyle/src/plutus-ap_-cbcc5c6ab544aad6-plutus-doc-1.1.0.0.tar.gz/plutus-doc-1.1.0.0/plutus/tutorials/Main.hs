module Main where

import PlutusTx ()

main :: IO ()
main = pure ()
